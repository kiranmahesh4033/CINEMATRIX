package com.cinematrix.service;

import com.cinematrix.dto.LoginRequest;
import com.cinematrix.dto.RegisterRequest;
import com.cinematrix.exception.UserAlreadyExistsException;
import com.cinematrix.exception.UserNotFoundException;
import com.cinematrix.model.User;
import com.cinematrix.repository.UserRepository;
import com.cinematrix.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    /**
     * Register a new user (only role=USER allowed through frontend).
     */
    public User register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new UserAlreadyExistsException("Email already registered");
        }

        User newUser = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role("USER") // Always register as USER from frontend
                .build();

        return userRepository.save(newUser);
    }

    /**
     * Authenticate a user and return a JWT token.
     */
    public String login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        if (!authentication.isAuthenticated()) {
            throw new RuntimeException("Invalid credentials");
        }

        // ✅ Fetch user details to include in token
        User user = getUserByEmail(request.getEmail());

        return jwtUtil.generateToken(user.getEmail(), user.getId(), user.getRole());
    }

    /**
     * Get full User object by email (used after login).
     */
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    public User registerAdmin(RegisterRequest request) {
        final String ADMIN_SECRET = "SUPERSECRET123"; // replace with strong secret & put in .env in production

        if (!ADMIN_SECRET.equals(request.getSecretKey())) {
            throw new RuntimeException("Invalid secret key");
        }

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new UserAlreadyExistsException("Email already registered");
        }

        User newUser = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role("ADMIN")
                .build();

        return userRepository.save(newUser);
    }

}
