package com.cinematrix.service;

import com.cinematrix.model.Movie;
import com.cinematrix.model.Show;
import com.cinematrix.repository.MovieRepository;
import com.cinematrix.repository.ShowRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MovieService {

    private final MovieRepository movieRepository;
    private final ShowRepository showRepository;

    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    public Movie getMovieById(Long id) {
        return movieRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("🎬 Movie not found with ID: " + id));
    }

    public Movie addMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    public void deleteMovie(Long id) {
        if (!movieRepository.existsById(id)) {
            throw new RuntimeException("❌ Cannot delete. Movie not found with ID: " + id);
        }
        movieRepository.deleteById(id);
    }

    public List<Movie> getMoviesByCity(String city) {
        List<Show> showsInCity = showRepository.findShowsWithMoviesByCity(city);

        Set<Movie> movies = showsInCity.stream()
                .map(Show::getMovie)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        return new ArrayList<>(movies);
    }

    public List<String> getAllCities() {
        List<String> cities = showRepository.findAllCities();

        return cities.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .map(city -> Character.toUpperCase(city.charAt(0)) + city.substring(1).toLowerCase())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }
}
