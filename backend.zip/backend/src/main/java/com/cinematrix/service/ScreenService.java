package com.cinematrix.service;

import com.cinematrix.dto.ScreenRequest;
import com.cinematrix.model.Screen;
import com.cinematrix.model.Theater;
import com.cinematrix.repository.ScreenRepository;
import com.cinematrix.repository.TheaterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ScreenService {

    private final ScreenRepository screenRepo;
    private final TheaterRepository theaterRepo;

    /**
     * Add a new screen to a theater.
     *
     * @param req ScreenRequest containing name, total seats, and theaterId
     * @return the saved Screen entity
     */
    public Screen addScreen(ScreenRequest req) {
        Theater theater = theaterRepo.findById(req.getTheaterId())
                .orElseThrow(() -> new RuntimeException("❌ Theater not found with ID: " + req.getTheaterId()));

        Screen screen = new Screen();
        screen.setName(req.getName());
        screen.setTotalSeats(req.getTotalSeats());
        screen.setTheater(theater);

        return screenRepo.save(screen);
    }

    /**
     * Get all screens in a specific theater.
     *
     * @param theaterId ID of the theater
     * @return List of screens
     */
    public List<Screen> getScreensByTheater(Long theaterId) {
        return screenRepo.findByTheater_Id(theaterId);
    }

    /**
     * Get all screens across all theaters.
     *
     * @return List of screens
     */
    public List<Screen> getAll() {
        return screenRepo.findAll();
    }
}
