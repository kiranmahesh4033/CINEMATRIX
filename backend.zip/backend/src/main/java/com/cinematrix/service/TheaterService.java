package com.cinematrix.service;

import com.cinematrix.model.Theater;
import com.cinematrix.repository.TheaterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TheaterService {

    private final TheaterRepository theaterRepo;

    /**
     * Fetch all theaters.
     *
     * @return List of all theaters
     */
    public List<Theater> getAll() {
        return theaterRepo.findAll();
    }

    /**
     * Get all theaters located in a specific city.
     *
     * @param city city name to filter
     * @return List of theaters in that city
     */
    public List<Theater> getByCity(String city) {
        return theaterRepo.findByCity(city);
    }

    /**
     * Create a new theater.
     *
     * @param theater theater object
     * @return saved theater
     */
    public Theater create(Theater theater) {
        return theaterRepo.save(theater);
    }
}
