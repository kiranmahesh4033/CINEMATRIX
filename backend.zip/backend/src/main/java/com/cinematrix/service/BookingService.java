package com.cinematrix.service;

import com.cinematrix.model.*;
import com.cinematrix.repository.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private ShowRepository showRepo;

    @Autowired
    private SeatRepository seatRepo;

    /**
     * Create a new booking for a user and show with selected seats.
     */
    @Transactional
    public Booking createBooking(Long userId, Long showId, List<Long> seatIds) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Show show = showRepo.findById(showId)
                .orElseThrow(() -> new RuntimeException("Show not found"));

        List<Seat> seats = seatRepo.findByIdIn(seatIds);

        if (seats.size() != seatIds.size()) {
            throw new RuntimeException("Some seats not found");
        }

        for (Seat seat : seats) {
            if (seat.isBooked()) {
                throw new RuntimeException("Seat already booked: " + seat.getSeatNumber());
            }
        }

        // Mark seats as booked
        seats.forEach(seat -> seat.setBooked(true));
        seatRepo.saveAll(seats);

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setShow(show);
        booking.setSeats(seats);
        booking.setStatus("CONFIRMED");

        return bookingRepo.save(booking);
    }

    /**
     * Retrieve all bookings (for admin).
     */
    public List<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }

    /**
     * Retrieve bookings for a user by userId.
     */
    public List<Booking> getBookingsByUser(Long userId) {
        return bookingRepo.findByUserId(userId);
    }

    /**
     * Retrieve bookings filtered by status (CONFIRMED, CANCELLED, COMPLETED).
     */
    public List<Booking> getBookingsByStatus(String status) {
        return bookingRepo.findByStatus(status);
    }

    /**
     * Retrieve a single booking by ID.
     */
    public Booking getBookingById(Long id) {
        return bookingRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
    }

    /**
     * Cancel a booking (if not already started).
     */
    @Transactional
    public String cancelBooking(Long bookingId) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if ("CANCELLED".equals(booking.getStatus())) {
            return "Booking already cancelled";
        }

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime showStart = LocalDateTime.of(
                booking.getShow().getShowDate(),
                booking.getShow().getStartTime()
        );

        if (now.isAfter(showStart)) {
            return "Cannot cancel booking after show has started";
        }

        booking.setStatus("CANCELLED");

        // Free seats
        booking.getSeats().forEach(seat -> seat.setBooked(false));
        seatRepo.saveAll(booking.getSeats());

        bookingRepo.save(booking);
        return "Booking cancelled successfully";
    }

    /**
     * Update status of a booking manually (admin).
     */
    @Transactional
    public void updateStatus(Long bookingId, String newStatus) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if ("CANCELLED".equals(booking.getStatus())) {
            throw new RuntimeException("Booking is already cancelled");
        }

        if ("CANCELLED".equalsIgnoreCase(newStatus)) {
            booking.setStatus("CANCELLED");
            booking.getSeats().forEach(seat -> seat.setBooked(false));
            seatRepo.saveAll(booking.getSeats());
        } else {
            booking.setStatus(newStatus.toUpperCase());
        }

        bookingRepo.save(booking);
    }
}
