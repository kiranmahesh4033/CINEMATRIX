package com.cinematrix.service;

import com.cinematrix.model.Seat;
import com.cinematrix.model.Show;
import com.cinematrix.repository.SeatRepository;
import com.cinematrix.repository.ShowRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SeatService {

    private final SeatRepository seatRepo;
    private final ShowRepository showRepo;

    /**
     * Retrieve all seats for a specific show.
     */
    public List<Seat> getSeatsByShow(Long showId) {
        return seatRepo.findByShowId(showId);
    }

    /**
     * Add a list of seats to a show.
     */
    public List<Seat> addSeatsToShow(Long showId, List<Seat> seats) {
        Show show = showRepo.findById(showId)
                .orElseThrow(() -> new RuntimeException("❌ Show not found with ID: " + showId));

        for (Seat seat : seats) {
            seat.setShow(show);
            seat.setBooked(false); // default to unbooked
        }

        return seatRepo.saveAll(seats);
    }

    /**
     * Unlock seats (e.g., after failed booking or cancellation).
     */
    public void unlockSeats(List<Long> seatIds) {
        List<Seat> seats = seatRepo.findByIdIn(seatIds);
        for (Seat seat : seats) {
            seat.setBooked(false);
        }
        seatRepo.saveAll(seats);
    }

    /**
     * Attempt to lock (book) a seat.
     * Throws if seat is already booked.
     */
    public Seat lockSeat(Long seatId) {
        Seat seat = seatRepo.findById(seatId)
                .orElseThrow(() -> new RuntimeException("❌ Seat not found with ID: " + seatId));

        if (seat.isBooked()) {
            throw new RuntimeException("❌ Seat already booked");
        }

        seat.setBooked(true);
        return seatRepo.save(seat);
    }
}
