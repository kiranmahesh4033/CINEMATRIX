package com.cinematrix.service;

import com.cinematrix.model.Movie;
import com.cinematrix.model.Screen;
import com.cinematrix.model.Show;
import com.cinematrix.repository.MovieRepository;
import com.cinematrix.repository.ScreenRepository;
import com.cinematrix.repository.ShowRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ShowService {

    private final ShowRepository showRepo;
    private final MovieRepository movieRepo;
    private final ScreenRepository screenRepo;

    /**
     * Add a new show by linking a movie and a screen.
     */
    public Show addShow(Long movieId, Long screenId, Show show) {
        Movie movie = movieRepo.findById(movieId)
                .orElseThrow(() -> new EntityNotFoundException("Movie not found with ID: " + movieId));
        Screen screen = screenRepo.findById(screenId)
                .orElseThrow(() -> new EntityNotFoundException("Screen not found with ID: " + screenId));

        show.setMovie(movie);
        show.setScreen(screen);
        return showRepo.save(show);
    }

    /**
     * Get all available shows.
     */
    public List<Show> getAllShows() {
        return showRepo.findAll();
    }

    /**
     * ✅ Get shows by movie ID with screen, theater, and movie joined.
     * This prevents LazyInitializationException and frontend undefined errors.
     */
    public List<Show> getShowsByMovie(Long movieId) {
        return showRepo.findDetailedByMovieId(movieId);  // use join fetch version
    }

    /**
     * Get shows by screen ID.
     */
    public List<Show> getShowsByScreen(Long screenId) {
        return showRepo.findByScreen_Id(screenId);
    }
    public Show getShowById(Long id) {
        return showRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Show not found with ID: " + id));
    }

}
