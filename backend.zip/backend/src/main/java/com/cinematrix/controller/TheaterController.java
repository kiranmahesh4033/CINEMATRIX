package com.cinematrix.controller;

import com.cinematrix.model.Theater;
import com.cinematrix.service.TheaterService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/theaters")
@CrossOrigin(origins = "http://localhost:3000") // change this in production
@RequiredArgsConstructor
public class TheaterController {

    private final TheaterService service;

    @GetMapping
    public ResponseEntity<List<Theater>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @GetMapping("/city/{city}")
    public ResponseEntity<List<Theater>> getByCity(@PathVariable String city) {
        return ResponseEntity.ok(service.getByCity(city));
    }

    @PostMapping
    public ResponseEntity<Theater> create(@RequestBody Theater theater) {
        Theater saved = service.create(theater);
        return ResponseEntity.ok(saved);
    }
}
