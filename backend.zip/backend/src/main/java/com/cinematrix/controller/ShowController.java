package com.cinematrix.controller;

import com.cinematrix.dto.ShowRequest;
import com.cinematrix.model.Show;
import com.cinematrix.service.ShowService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shows")
@CrossOrigin(origins = "http://localhost:3000") // 🔁 Adjust in production
@RequiredArgsConstructor
public class ShowController {

    private final ShowService showService;

    // ✅ Get all shows
    @GetMapping
    public ResponseEntity<List<Show>> getAllShows() {
        return ResponseEntity.ok(showService.getAllShows());
    }

    // ✅ Get shows by movie ID
    @GetMapping("/movie/{movieId}")
    public ResponseEntity<List<Show>> getByMovie(@PathVariable Long movieId) {
        return ResponseEntity.ok(showService.getShowsByMovie(movieId));
    }

    // ✅ Get shows by screen ID
    @GetMapping("/screen/{screenId}")
    public ResponseEntity<List<Show>> getByScreen(@PathVariable Long screenId) {
        return ResponseEntity.ok(showService.getShowsByScreen(screenId));
    }

    // ✅ Add new show
    @PostMapping
    public ResponseEntity<Show> addShow(@Valid @RequestBody ShowRequest request) {
        Show show = new Show();
        show.setShowDate(request.getShowDate());
        show.setStartTime(request.getStartTime());

        Show savedShow = showService.addShow(request.getMovieId(), request.getScreenId(), show);
        return ResponseEntity.ok(savedShow);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Show> getShowById(@PathVariable Long id) {
        Show show = showService.getShowById(id);
        return ResponseEntity.ok(show);
    }

}
