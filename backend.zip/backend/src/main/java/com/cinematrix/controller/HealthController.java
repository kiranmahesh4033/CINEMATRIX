package com.cinematrix.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.sql.DataSource;
import java.sql.Connection;

@RestController
@RequestMapping("/api/health")
@RequiredArgsConstructor
public class HealthController {

    private final DataSource dataSource;

    @GetMapping
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Application is running");
    }

    @GetMapping("/db")
    public ResponseEntity<String> dbHealthCheck() {
        try (Connection conn = dataSource.getConnection()) {
            if (!conn.isClosed()) {
                return ResponseEntity.ok("Database connection OK");
            }
        } catch (Exception e) {
            return ResponseEntity.status(503).body("Database connection failed: " + e.getMessage());
        }
        return ResponseEntity.status(503).body("Database connection unavailable");
    }
}
