package com.cinematrix.controller;

import com.cinematrix.dto.LoginRequest;
import com.cinematrix.dto.RegisterRequest;
import com.cinematrix.model.User;
import com.cinematrix.service.AuthService;
import com.cinematrix.utils.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {
        try {
            User user = authService.register(request);
            return ResponseEntity.ok(Map.of(
                    "message", "Registration successful",
                    "userId", user.getId()
            ));
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", ex.getMessage()
            ));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        try {
            String token = authService.login(request);
            User user = authService.getUserByEmail(request.getEmail());

            return ResponseEntity.ok(Map.of(
                    "token", token,
                    "user", Map.of(
                            "id", user.getId(),
                            "email", user.getEmail(),
                            "fullName", user.getFullName(),
                            "role", user.getRole()
                    )
            ));
        } catch (RuntimeException ex) {
            return ResponseEntity.status(401).body(Map.of(
                    "message", ex.getMessage()
            ));
        }
    }


    @PostMapping("/admin/register")
    public ResponseEntity<?> registerAdmin(@Valid @RequestBody RegisterRequest request) {
        try {
            User user = authService.registerAdmin(request);
            return ResponseEntity.ok(Map.of(
                    "message", "Admin registration successful",
                    "userId", user.getId()
            ));
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", ex.getMessage()
            ));
        }
    }
}

