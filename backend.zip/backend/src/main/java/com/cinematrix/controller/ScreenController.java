package com.cinematrix.controller;

import com.cinematrix.dto.ScreenRequest;
import com.cinematrix.model.Screen;
import com.cinematrix.service.ScreenService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/screens")
@CrossOrigin(origins = "http://localhost:3000") // Update for production
@RequiredArgsConstructor
public class ScreenController {

    private final ScreenService screenService;

    @GetMapping("/theater/{theaterId}")
    public ResponseEntity<List<Screen>> getScreensByTheater(@PathVariable Long theaterId) {
        List<Screen> screens = screenService.getScreensByTheater(theaterId);
        return ResponseEntity.ok(screens);
    }

    @PostMapping
    public ResponseEntity<Screen> addScreen(@Valid @RequestBody ScreenRequest req) {
        Screen screen = screenService.addScreen(req);
        return ResponseEntity.ok(screen);
    }

    @GetMapping
    public ResponseEntity<List<Screen>> getAll() {
        return ResponseEntity.ok(screenService.getAll());
    }
}
