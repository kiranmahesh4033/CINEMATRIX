package com.cinematrix.controller;

import com.cinematrix.model.Seat;
import com.cinematrix.service.SeatService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seats")
@CrossOrigin(origins = "http://localhost:3000") // Use "*" only in development if needed
@RequiredArgsConstructor
public class SeatController {

    private final SeatService seatService;

    @GetMapping("/show/{showId}")
    public ResponseEntity<List<Seat>> getSeatsByShow(@PathVariable Long showId) {
        List<Seat> seats = seatService.getSeatsByShow(showId);
        return ResponseEntity.ok(seats);
    }

    @PostMapping("/show/{showId}")
    public ResponseEntity<List<Seat>> addSeats(@PathVariable Long showId, @RequestBody List<Seat> seats) {
        List<Seat> addedSeats = seatService.addSeatsToShow(showId, seats);
        return ResponseEntity.ok(addedSeats);
    }

    @PostMapping("/lock/{seatId}")
    public ResponseEntity<Seat> lockSeat(@PathVariable Long seatId) {
        Seat locked = seatService.lockSeat(seatId);
        return ResponseEntity.ok(locked);
    }
}
