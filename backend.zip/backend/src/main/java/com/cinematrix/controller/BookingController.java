package com.cinematrix.controller;

import com.cinematrix.model.Booking;
import com.cinematrix.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    // ✅ Create a booking
    @PostMapping
    public ResponseEntity<?> createBooking(
            @RequestParam Long userId,
            @RequestParam Long showId,
            @RequestBody List<Long> seatIds) {
        Booking booking = bookingService.createBooking(userId, showId, seatIds);
        return ResponseEntity.ok(booking);
    }

    // ✅ Get all bookings or filter by status
    @GetMapping
    public ResponseEntity<?> getAllBookings(@RequestParam(required = false) String status) {
        List<Booking> bookings = (status == null || status.equalsIgnoreCase("all"))
                ? bookingService.getAllBookings()
                : bookingService.getBookingsByStatus(status.toUpperCase());
        return ResponseEntity.ok(bookings);
    }

    // ✅ Get bookings by userId
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getBookingsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(bookingService.getBookingsByUser(userId));
    }

    // ✅ Get booking by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookingById(@PathVariable Long id) {
        return ResponseEntity.ok(bookingService.getBookingById(id));
    }

    // ✅ Cancel a booking (user)
    @PutMapping("/{id}/cancel")
    public ResponseEntity<?> cancelBooking(@PathVariable Long id) {
        String result = bookingService.cancelBooking(id);
        return ResponseEntity.ok(Map.of("message", result));
    }

    // ✅ Update booking status (admin)
    @PatchMapping("/{id}")
    public ResponseEntity<?> updateBookingStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String newStatus = body.get("status");
        bookingService.updateStatus(id, newStatus);
        return ResponseEntity.ok(Map.of("message", "Booking status updated"));
    }
}
