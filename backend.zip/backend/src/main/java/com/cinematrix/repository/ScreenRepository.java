package com.cinematrix.repository;

import com.cinematrix.model.Screen;
import com.cinematrix.model.Theater;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ScreenRepository extends JpaRepository<Screen, Long> {

    // ✅ Add this:
    List<Screen> findByTheater_Id(Long theaterId);

    // OR this is also valid:
    // List<Screen> findByTheater(Theater theater);
}
