package com.cinematrix.repository;

import com.cinematrix.model.Show;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ShowRepository extends JpaRepository<Show, Long> {

    // 🔍 Basic find
    List<Show> findByMovie_Id(Long movieId);

    List<Show> findByScreen_Id(Long screenId);

    // ✅ Native: Distinct cities
    @Query(value = "SELECT DISTINCT t.city FROM shows s " +
            "JOIN screen sc ON s.screen_id = sc.id " +
            "JOIN theater t ON sc.theater_id = t.id",
            nativeQuery = true)
    List<String> findAllCities();

    // ✅ Native: Movies by city
    @Query(value = "SELECT s.* FROM shows s " +
            "JOIN screen sc ON s.screen_id = sc.id " +
            "JOIN theater t ON sc.theater_id = t.id " +
            "JOIN movie m ON s.movie_id = m.id " +
            "WHERE UPPER(t.city) = UPPER(:city)",
            nativeQuery = true)
    List<Show> findShowsWithMoviesByCity(@Param("city") String city);

    // ✅ JPQL: Eagerly fetch movie, screen, theater for frontend safety
    @Query("SELECT s FROM Show s " +
            "JOIN FETCH s.movie m " +
            "JOIN FETCH s.screen sc " +
            "JOIN FETCH sc.theater t " +
            "WHERE m.id = :movieId")
    List<Show> findDetailedByMovieId(@Param("movieId") Long movieId);
}
