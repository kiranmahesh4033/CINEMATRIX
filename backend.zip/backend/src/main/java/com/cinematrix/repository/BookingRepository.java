package com.cinematrix.repository;

import com.cinematrix.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    // ✅ For fetching all bookings by a specific user
    List<Booking> findByUserId(Long userId);

    // ✅ For filtering bookings by status (CONFIRMED, CANCELLED, COMPLETED)
    List<Booking> findByStatus(String status);
}
