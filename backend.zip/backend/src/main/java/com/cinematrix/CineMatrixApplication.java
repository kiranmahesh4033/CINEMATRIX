package com.cinematrix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CineMatrixApplication {

	public static void main(String[] args) {
		SpringApplication.run(CineMatrixApplication.class, args);
	}

}
