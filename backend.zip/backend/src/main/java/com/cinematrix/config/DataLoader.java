package com.cinematrix.config;

import com.cinematrix.model.Movie;
import com.cinematrix.repository.MovieRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataLoader {

    private final MovieRepository movieRepository;

    @PostConstruct
    public void loadData() {
        if (movieRepository.count() == 0) {
            Movie m1 = Movie.builder()
                    .title("Inception")
                    .genre("Sci-Fi")
                    .language("English")
                    .description("A mind-bending thriller by Christopher Nolan.")
                    .posterUrl("https://image.tmdb.org/t/p/w500/qmDpIHrmpJINaRKAfWQfftjCdyi.jpg")
                    .build();

            Movie m2 = Movie.builder()
                    .title("Baahubali")
                    .genre("Action")
                    .language("Telugu")
                    .description("Epic story of kings, betrayal, and war.")
                    .posterUrl("https://image.tmdb.org/t/p/w500/k66GxS5BdEq2hi8ZxZpbdmlQ2.jpg") // ✅ fixed URL
                    .build();

            movieRepository.save(m1);
            movieRepository.save(m2);

            System.out.println("✅ Sample movies inserted into database.");
        }
    }
}
